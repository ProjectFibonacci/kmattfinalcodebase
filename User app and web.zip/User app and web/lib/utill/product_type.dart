class ProductType{
  static const String dailyItem = 'daily_needs';
  static const String searchItem = 'searchItem';
  static const String featuredItem = 'featuredItems';
  static const String mostReviewed = 'mostReviewed_items';
  static const String recommendProduct = 'recommend_items';
  static const String flashSale = 'flash_deal';

}