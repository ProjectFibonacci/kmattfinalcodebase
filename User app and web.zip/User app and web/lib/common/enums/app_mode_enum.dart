enum AppMode{
  release,
  demo,
}