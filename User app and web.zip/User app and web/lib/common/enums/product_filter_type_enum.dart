enum ProductFilterType{
  latest,
  popular,
  recommended,
  trending,
}